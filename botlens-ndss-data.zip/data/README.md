# BotLens — Data Component

Companion data for the BotLens code archive. Unpack so that this `data/` directory
sits in the repository root, next to `config/` and `scripts/`.

Verify integrity first:

```bash
sha256sum -c SHA256SUMS.txt
```

## Contents

```
data/
├── processed/
│   ├── all_reviews_classified.csv   515 MB  183,142 reviews, binary S&P label
│   ├── bot_metadata_cleaned.csv      42 MB  23,102 bots — required for Table I's
│   │                                        bot count and the 0.77% privacy-policy
│   │                                        figure (Sec. IV-D6); the review file
│   │                                        alone covers only the 11,980 bots that
│   │                                        actually received reviews
│   ├── privacy_reviews_full.csv      28 MB  8,832 S&P reviews + theme + affect
│   ├── train.csv                      1,689 rows  (30% labeling budget, post-balancing)
│   ├── val.csv                          211 rows
│   ├── test.csv                         212 rows  (the 98-positive eval split is drawn here)
│   └── label_map.json
├── results/
│   ├── analysis_summary.json          Headline numbers (Table I, Sec. IV-A)
│   ├── theme_distribution.csv         TPR per theme — see note below
│   ├── sprr_by_bot.csv                Per-bot SPRR
│   ├── sprr_by_category.csv           Per-tag SPRR (Fig. 6)
│   ├── emotion_by_theme.csv           Affective expression by theme (Fig. 8)
│   ├── rq3_feature_correlations.csv   Spearman rho of each feature with SPRR (Fig. 14)
│   ├── labeling_experiment_results.csv  Labeling-budget sweep (Table II)
│   ├── language_distribution.csv      53-value language breakdown reproducing
│   │                                  Table IV over the 201,733 raw reviews
│   ├── language_affective_distribution.csv  Fig. 17 percentages by language
│   ├── language_affective_counts.csv        Fig. 17 supporting counts
│   └── language_affective_raw_counts.csv    Fig. 17 raw label counts
├── reference_figures/                 Our output of every figure the scripts generate
│                                      (paper Figs. 2–14, 17, 18), named by figure
│                                      number, for diffing against your own run
└── irr/
    ├── IRR_Annotator1.xlsx            Independent annotations, annotator 1
    ├── IRR_Annotator2.xlsx            Independent annotations, annotator 2
    └── IRR_Results.xlsx               Cohen's kappa output (Sec. III-C3)

Label columns are named `Annotator 1 Label` / `Annotator 2 Label`, which is what
`compute_kappa.py` expects. Annotator identities have been removed from sheet
titles, instructions, headers and results tabs; review text is unmodified.
```

`compute_kappa.py` reads both workbooks from `data/irr/` and writes its results to
`data/results/IRR_Results.xlsx`, leaving the shipped `data/irr/IRR_Results.xlsx`
untouched.

## License

Licensed under CC BY-NC-SA 4.0. The CC BY-NC-SA 4.0 license applies strictly to
the annotations, labels, and dataset compilation created by the authors. The
underlying data remains subject to the original creators' terms. See `LICENSE` in
this directory. The code is licensed separately under the MIT License.

## Privacy notice

Top.gg shows a reviewer display name next to each review. **These identifiers have
been removed from every file in this bundle** — the `username` column is dropped, and
no reviewer identifier is used as an analysis variable anywhere in the pipeline. The
distributed files contain review text, public bot metadata, and model-assigned
labels only.

Review *text* is reproduced as written and may occasionally contain self-disclosed
personal references. We report all findings in aggregate and publish no PII; please
treat the text column accordingly.

Bot-level fields (`name`, `creators`, `invite_url`, `github_url`, `permissions`) are
public listing information and are retained, since the analysis operates on them.

## Note on `theme_distribution.csv`

This file lists 14 themes summing to 8,647 rather than all 30 observed values
summing to 8,832. That is intended: `stage7_analysis.py` applies
`MIN_REVIEWS_PER_THEME = 50` (`config/settings.py`), so themes with fewer than 50
reviews are omitted from the reported distribution. The 185 excluded reviews belong
to low-frequency themes (Surveillance 48, Data Retention 43, Data Accuracy 32, and
smaller). The full unfiltered distribution is recoverable from
`privacy_reviews_full.csv` by counting `primary_theme`.

The column is named `tpr` (it was `ptpr` in an earlier release, before the
PPR->SPRR rename). It is computed over all 8,832 S&P reviews, including those labeled
`unassigned` — matching the percentages reported in the paper.

## Note on `bot_id`

`bot_id` in `all_reviews_classified.csv` and `privacy_reviews_full.csv` is rounded.
Discord IDs are 19-digit snowflakes and passed through a 64-bit float during
preprocessing, so the trailing digits are zeroed: 11,978 of the 11,980 distinct IDs
in the review corpus end in three or more zeros. `bot_metadata_cleaned.csv` retains
the exact IDs.

**Do not join the review files to `bot_metadata_cleaned.csv` on `bot_id`** — only 16
IDs match. Join on `name` instead, which covers 10,388 of the 11,210 names in the
review corpus.

No result in the paper is affected. Every analysis groups by `bot_id` within a
single file, where the rounded values are still unique and internally consistent,
and the bot-level metadata a reviewer needs (`permissions`, `permissions_decoded`,
`server_count`, `average_rating`, `tags`, `has_github`) is already merged into
`all_reviews_classified.csv`, so no cross-file join is required to reproduce
anything. `bot_metadata_cleaned.csv` is used standalone, for the 23,102 bot count
and the privacy-policy rate.

Because of the rounding, `bot_id` should not be used to look bots up on Discord or
Top.gg. Use `name`.

## Coverage

The metadata covers 23,102 bots; 11,980 of them have at least one review in the
corpus. Table I's bot count is the metadata figure, and the review-derived rates are
computed over the bots that actually received reviews.

## Provenance

These files are the output of Stages 4–7 of the pipeline. Stages 0–4 require the raw
Top.gg crawl, a local Ollama instance, and a fine-tuned DeBERTa checkpoint; see
`ARTIFACT-EVALUATION.md` §6 for what can and cannot be re-run end to end. The raw
crawl is not redistributed because it contains the reviewer display names that are
stripped here.
